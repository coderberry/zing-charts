package zingchart

class ZingChartExamplesController {

    def index = { }
    
}
