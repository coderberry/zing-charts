package zingchart.chartGraphSet

class Series {

    def seriesValues = []

}
