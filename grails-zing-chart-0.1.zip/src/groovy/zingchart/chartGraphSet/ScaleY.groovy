package zingchart.chartGraphSet

class ScaleY {

    def labels = []
    String backgroundColor1 // Optional
    String backgroundColor2 // Optional
    Boolean mirrored = false // True for vertically mirror graph

}
