package zingchart.chartGraphSet

class SeriesValues {

    String title
    Boolean animate
    Float animateSpeed = 1.0
    Integer effect
    ArrayList<Float> values 

}
