package zingchart.chartGraphSet

class ScaleX {

    def labels = []
    Float offsetStart // Optional
    Boolean showLabelsOnTop = false // Try to show labels on top instead of bottom

}
